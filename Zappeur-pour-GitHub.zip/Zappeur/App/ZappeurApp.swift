import SwiftUI
import AVFoundation

@main
struct ZappeurApp: App {
    @StateObject private var model = AppModel()

    init() {
        // Cache plus généreux pour les logos des chaînes.
        URLCache.shared = URLCache(memoryCapacity: 64 * 1024 * 1024,
                                   diskCapacity: 256 * 1024 * 1024,
                                   directory: nil)
        // Session audio « lecture » : indispensable pour le son en arrière-plan et le Picture-in-Picture.
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .moviePlayback, options: [])
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(model)
                .preferredColorScheme(.dark)
        }
    }
}

import Foundation
import Combine

enum GroupSelection: Hashable {
    case favorites
    case recents
    case all
    case group(String)
}

struct ChannelGroup: Identifiable, Hashable {
    let name: String
    let count: Int
    var id: String { name }
}

struct NowNext {
    var current: Programme?
    var next: Programme?
}

enum EPGStatus: Equatable {
    case idle
    case unavailable
    case loading
    case loaded(Int)
    case failed(String)
}

/// État central de l'appli : playlists, chaînes, favoris, guide TV et lecture.
@MainActor
final class AppModel: ObservableObject {
    @Published private(set) var playlists: [PlaylistConfig] = []
    @Published private(set) var activePlaylistID: UUID? = nil
    @Published private(set) var allChannels: [Channel] = []
    @Published private(set) var groups: [ChannelGroup] = []
    @Published var selection: GroupSelection = .all
    @Published private(set) var favoriteIDs: Set<String> = []
    @Published private(set) var recentIDs: [String] = []
    @Published private(set) var isLoadingChannels = false
    @Published private(set) var loadError: String? = nil
    @Published private(set) var epgStatus: EPGStatus = .idle
    @Published private(set) var epg: [String: [Programme]] = [:]
    @Published private(set) var shortEPG: [String: [Programme]] = [:]
    @Published private(set) var now = Date()
    @Published var preferHLS: Bool = true {
        didSet {
            UserDefaults.standard.set(preferHLS, forKey: Keys.preferHLS)
            playback.preferHLS = preferHLS
        }
    }

    let playback = PlayerController()

    private var channelIndex: [String: Channel] = [:]
    private var channelsByGroup: [String: [Channel]] = [:]
    private var playlistEPGURL: URL?
    private var loadGeneration = 0
    private var shortEPGRequests: Set<String> = []
    private var clockTask: Task<Void, Never>?

    private enum Keys {
        static let preferHLS = "settings.preferHLS"
        static let active = "playlists.active"

        static func favorites(_ id: UUID) -> String { "favorites.\(id.uuidString)" }
        static func recents(_ id: UUID) -> String { "recents.\(id.uuidString)" }
    }

    init() {
        let defaults = UserDefaults.standard
        preferHLS = defaults.object(forKey: Keys.preferHLS) as? Bool ?? true
        playback.preferHLS = preferHLS
        playlists = PlaylistStore.load()
        if let raw = defaults.string(forKey: Keys.active),
           let id = UUID(uuidString: raw),
           playlists.contains(where: { $0.id == id }) {
            activePlaylistID = id
        } else {
            activePlaylistID = playlists.first?.id
        }
        startClock()
        bootstrapActivePlaylist()
    }

    var activePlaylist: PlaylistConfig? {
        guard let id = activePlaylistID else { return nil }
        return playlists.first { $0.id == id }
    }

    // MARK: - Chaînes

    func channels(for selection: GroupSelection) -> [Channel] {
        switch selection {
        case .all:
            return allChannels
        case .favorites:
            return allChannels.filter { favoriteIDs.contains($0.id) }
        case .recents:
            return recentIDs.compactMap { channelIndex[$0] }
        case .group(let name):
            return channelsByGroup[name] ?? []
        }
    }

    func search(_ query: String) -> [Channel] {
        let text = query.trimmed
        guard !text.isEmpty else { return [] }
        var results: [Channel] = []
        for channel in allChannels where channel.name.range(of: text, options: [.caseInsensitive, .diacriticInsensitive]) != nil {
            results.append(channel)
            if results.count >= 300 {
                break
            }
        }
        return results
    }

    func title(for selection: GroupSelection) -> String {
        switch selection {
        case .favorites: return "Favoris"
        case .recents: return "Récents"
        case .all: return "Toutes les chaînes"
        case .group(let name): return name
        }
    }

    var favoritesCount: Int {
        allChannels.reduce(0) { $0 + (favoriteIDs.contains($1.id) ? 1 : 0) }
    }

    var recentsCount: Int {
        recentIDs.reduce(0) { $0 + (channelIndex[$1] != nil ? 1 : 0) }
    }

    func reloadChannels() async {
        guard let config = activePlaylist else { return }
        loadGeneration += 1
        let generation = loadGeneration
        isLoadingChannels = true
        loadError = nil
        let password = Keychain.read(account: config.id.uuidString) ?? ""
        do {
            let loaded = try await Task.detached(priority: .userInitiated) {
                try await PlaylistLoader.load(config: config, password: password)
            }.value
            guard generation == loadGeneration else { return }
            apply(channels: loaded.channels, epgURL: loaded.epgURL)
            isLoadingChannels = false
            let snapshot = CachedPlaylist(savedAt: Date(), channels: loaded.channels, epgURL: loaded.epgURL)
            let playlistID = config.id
            Task.detached(priority: .utility) {
                ChannelCache.save(snapshot, for: playlistID)
            }
            await reloadEPG(force: false)
        } catch {
            guard generation == loadGeneration else { return }
            isLoadingChannels = false
            loadError = error.localizedDescription
        }
    }

    private func apply(channels: [Channel], epgURL: URL?) {
        allChannels = channels
        playlistEPGURL = epgURL
        var index: [String: Channel] = [:]
        var byGroup: [String: [Channel]] = [:]
        var order: [String] = []
        index.reserveCapacity(channels.count)
        for channel in channels {
            index[channel.id] = channel
            if byGroup[channel.group] == nil {
                order.append(channel.group)
            }
            byGroup[channel.group, default: []].append(channel)
        }
        channelIndex = index
        channelsByGroup = byGroup
        groups = order.map { ChannelGroup(name: $0, count: byGroup[$0]?.count ?? 0) }
        if case .group(let name) = selection, byGroup[name] == nil {
            selection = .all
        }
    }

    // MARK: - Guide TV

    func programmes(for channel: Channel) -> [Programme] {
        if let key = channel.epgID, let list = epg[key], !list.isEmpty {
            return list
        }
        return shortEPG[channel.id] ?? []
    }

    func nowAndNext(for channel: Channel) -> NowNext {
        let list = programmes(for: channel)
        guard let index = list.firstIndex(where: { $0.end > now }) else { return NowNext() }
        let item = list[index]
        if item.start <= now {
            return NowNext(current: item, next: index + 1 < list.count ? list[index + 1] : nil)
        }
        return NowNext(current: nil, next: item)
    }

    var epgStatusDescription: String {
        switch epgStatus {
        case .idle: return "En attente"
        case .unavailable: return "Aucun guide disponible"
        case .loading: return "Chargement…"
        case .loaded(let count): return count > 1 ? "\(count) chaînes renseignées" : "\(count) chaîne renseignée"
        case .failed(let message): return "Erreur : \(message)"
        }
    }

    func reloadEPG(force: Bool) async {
        guard let config = activePlaylist else { return }
        if epgStatus == .loading && !force {
            return
        }
        let wanted = Set(allChannels.compactMap { $0.epgID })
        guard let url = epgURL(for: config), !wanted.isEmpty else {
            epgStatus = .unavailable
            return
        }
        let generation = loadGeneration
        let cacheKey = config.id.uuidString
        epgStatus = .loading
        do {
            let result = try await Task.detached(priority: .utility) {
                try await EPGLoader.load(url: url, cacheKey: cacheKey, force: force, wanted: wanted)
            }.value
            guard generation == loadGeneration else { return }
            epg = result
            epgStatus = .loaded(result.count)
        } catch {
            guard generation == loadGeneration else { return }
            epgStatus = .failed(error.localizedDescription)
        }
    }

    private func epgURL(for config: PlaylistConfig) -> URL? {
        if let custom = URL.lenient(config.epgURL) {
            return custom
        }
        switch config.kind {
        case .xtream:
            let password = Keychain.read(account: config.id.uuidString) ?? ""
            return XtreamAPI.xmltvURL(server: config.server, username: config.username, password: password)
        case .m3u:
            return playlistEPGURL
        }
    }

    /// Si le guide XMLTV ne connaît pas la chaîne, on demande son programme au serveur Xtream.
    private func loadShortEPGIfNeeded(for channel: Channel) {
        guard nowAndNext(for: channel).current == nil,
              let config = activePlaylist, config.kind == .xtream,
              let streamID = channel.xtreamStreamID,
              !shortEPGRequests.contains(channel.id) else { return }
        shortEPGRequests.insert(channel.id)
        let password = Keychain.read(account: config.id.uuidString) ?? ""
        let generation = loadGeneration
        let channelID = channel.id
        Task {
            let list = (try? await XtreamAPI.shortEPG(server: config.server,
                                                      username: config.username,
                                                      password: password,
                                                      streamID: streamID)) ?? []
            guard generation == self.loadGeneration, !list.isEmpty else { return }
            self.shortEPG[channelID] = list
        }
    }

    // MARK: - Favoris et récents

    func isFavorite(_ channel: Channel) -> Bool {
        favoriteIDs.contains(channel.id)
    }

    func toggleFavorite(_ channel: Channel) {
        if favoriteIDs.contains(channel.id) {
            favoriteIDs.remove(channel.id)
        } else {
            favoriteIDs.insert(channel.id)
        }
        guard let id = activePlaylistID else { return }
        UserDefaults.standard.set(Array(favoriteIDs), forKey: Keys.favorites(id))
    }

    private func markRecent(_ channel: Channel) {
        recentIDs.removeAll { $0 == channel.id }
        recentIDs.insert(channel.id, at: 0)
        if recentIDs.count > 30 {
            recentIDs.removeLast(recentIDs.count - 30)
        }
        guard let id = activePlaylistID else { return }
        UserDefaults.standard.set(recentIDs, forKey: Keys.recents(id))
    }

    // MARK: - Lecture

    func play(_ channel: Channel) {
        markRecent(channel)
        playback.play(channel)
        loadShortEPGIfNeeded(for: channel)
    }

    // MARK: - Playlists

    func save(_ config: PlaylistConfig, password: String?) {
        if let password = password {
            Keychain.save(password, account: config.id.uuidString)
        }
        let isNew = !playlists.contains { $0.id == config.id }
        if let index = playlists.firstIndex(where: { $0.id == config.id }) {
            playlists[index] = config
        } else {
            playlists.append(config)
        }
        PlaylistStore.save(playlists)
        ChannelCache.remove(for: config.id)
        EPGLoader.removeCache(for: config.id.uuidString)
        if isNew || config.id == activePlaylistID {
            activePlaylistID = nil
            activate(config.id)
        }
    }

    func activate(_ id: UUID) {
        guard id != activePlaylistID else { return }
        playback.stop()
        activePlaylistID = id
        UserDefaults.standard.set(id.uuidString, forKey: Keys.active)
        bootstrapActivePlaylist()
    }

    func deletePlaylists(at offsets: IndexSet) {
        let removed = offsets.map { playlists[$0] }
        for index in offsets.sorted(by: >) {
            playlists.remove(at: index)
        }
        PlaylistStore.save(playlists)
        let defaults = UserDefaults.standard
        for config in removed {
            Keychain.delete(account: config.id.uuidString)
            ChannelCache.remove(for: config.id)
            EPGLoader.removeCache(for: config.id.uuidString)
            defaults.removeObject(forKey: Keys.favorites(config.id))
            defaults.removeObject(forKey: Keys.recents(config.id))
        }
        if let active = activePlaylistID, removed.contains(where: { $0.id == active }) {
            activePlaylistID = nil
            defaults.removeObject(forKey: Keys.active)
            playback.stop()
            if let first = playlists.first {
                activate(first.id)
            } else {
                resetState()
            }
        }
    }

    // MARK: - Interne

    private func resetState() {
        loadGeneration += 1
        allChannels = []
        groups = []
        channelIndex = [:]
        channelsByGroup = [:]
        epg = [:]
        shortEPG = [:]
        shortEPGRequests = []
        favoriteIDs = []
        recentIDs = []
        epgStatus = .idle
        loadError = nil
        isLoadingChannels = false
        playlistEPGURL = nil
        selection = .all
    }

    private func bootstrapActivePlaylist() {
        resetState()
        guard let config = activePlaylist else { return }
        let defaults = UserDefaults.standard
        favoriteIDs = Set(defaults.stringArray(forKey: Keys.favorites(config.id)) ?? [])
        recentIDs = defaults.stringArray(forKey: Keys.recents(config.id)) ?? []
        selection = favoriteIDs.isEmpty ? .all : .favorites
        if let cached = ChannelCache.load(for: config.id) {
            apply(channels: cached.channels, epgURL: cached.epgURL)
            let isStale = Date().timeIntervalSince(cached.savedAt) > 12 * 3600
            Task {
                if isStale {
                    await self.reloadChannels()
                } else {
                    await self.reloadEPG(force: false)
                }
            }
        } else {
            isLoadingChannels = true
            Task {
                await self.reloadChannels()
            }
        }
    }

    /// Met à jour l'heure toutes les 30 s (barres de progression, programme en cours).
    private func startClock() {
        clockTask = Task { [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 30_000_000_000)
                self?.now = Date()
            }
        }
    }
}

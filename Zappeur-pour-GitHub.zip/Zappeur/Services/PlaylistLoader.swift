import Foundation

struct LoadedPlaylist {
    var channels: [Channel]
    /// Guide TV annoncé par la playlist M3U (url-tvg), s'il existe.
    var epgURL: URL?
}

enum PlaylistLoader {
    static func load(config: PlaylistConfig, password: String) async throws -> LoadedPlaylist {
        switch config.kind {
        case .xtream:
            let channels = try await XtreamAPI.liveChannels(server: config.server,
                                                            username: config.username,
                                                            password: password)
            guard !channels.isEmpty else { throw AppError.emptyPlaylist }
            return LoadedPlaylist(channels: channels, epgURL: nil)
        case .m3u:
            guard let url = URL.lenient(config.m3uURL) else { throw AppError.invalidURL }
            let data = try await Net.data(from: url)
            let parsed = M3UParser.parse(data)
            guard !parsed.channels.isEmpty else { throw AppError.emptyPlaylist }
            return LoadedPlaylist(channels: parsed.channels, epgURL: parsed.epgURL)
        }
    }
}

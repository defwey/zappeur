import Foundation

extension String {
    var trimmed: String {
        trimmingCharacters(in: .whitespacesAndNewlines)
    }
}

/// Renvoie la première valeur non vide (après suppression des espaces).
func firstNonEmpty(_ values: String?...) -> String? {
    for value in values {
        if let value = value?.trimmed, !value.isEmpty {
            return value
        }
    }
    return nil
}

extension URL {
    /// Crée une URL à partir d'un texte saisi ou lu dans une playlist, en tolérant espaces et accents.
    static func lenient(_ raw: String?) -> URL? {
        guard let text = raw?.trimmed, !text.isEmpty else { return nil }
        if let url = URL(string: text), url.scheme != nil, url.host != nil {
            return url
        }
        if let encoded = text.addingPercentEncoding(withAllowedCharacters: .urlLenientAllowed),
           let url = URL(string: encoded), url.scheme != nil, url.host != nil {
            return url
        }
        return nil
    }
}

extension CharacterSet {
    /// Caractères conservés tels quels quand on « répare » une URL.
    static let urlLenientAllowed: CharacterSet = {
        var set = CharacterSet.urlQueryAllowed
        set.formUnion(.urlPathAllowed)
        set.formUnion(.urlHostAllowed)
        set.insert(charactersIn: "%#")
        return set
    }()

    /// Caractères autorisés dans un segment de chemin (identifiant ou mot de passe Xtream).
    static let urlPathSegmentAllowed: CharacterSet = {
        var set = CharacterSet.urlPathAllowed
        set.remove(charactersIn: "/")
        return set
    }()
}

/// Hachage stable (FNV-1a 64 bits) : contrairement à `hashValue`, il ne change pas d'un lancement à l'autre.
enum StableHash {
    static func hex(_ text: String) -> String {
        var hash: UInt64 = 0xcbf2_9ce4_8422_2325
        for byte in text.utf8 {
            hash ^= UInt64(byte)
            hash = hash &* 0x0000_0100_0000_01b3
        }
        return String(hash, radix: 16)
    }
}

/// Lecture tolérante du JSON des serveurs Xtream (les nombres arrivent parfois en texte, et inversement).
extension Dictionary where Key == String, Value == Any {
    func string(_ key: String) -> String? {
        if let value = self[key] as? String { return value }
        if let value = self[key] as? NSNumber { return value.stringValue }
        return nil
    }

    func int(_ key: String) -> Int? {
        if let value = self[key] as? NSNumber { return value.intValue }
        if let value = self[key] as? String { return Int(value.trimmed) }
        return nil
    }

    func double(_ key: String) -> Double? {
        if let value = self[key] as? NSNumber { return value.doubleValue }
        if let value = self[key] as? String { return Double(value.trimmed) }
        return nil
    }
}

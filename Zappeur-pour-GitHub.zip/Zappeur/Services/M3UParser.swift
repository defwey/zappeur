import Foundation

struct M3UParseResult {
    var channels: [Channel]
    var epgURL: URL?
    var skippedVOD: Int
}

/// Lecture d'une playlist M3U / M3U Plus (attributs tvg-id, tvg-logo, group-title…).
/// Les films et séries (VOD) sont ignorés : cette version ne gère que le direct.
enum M3UParser {
    static func parse(_ data: Data) -> M3UParseResult {
        var channels: [Channel] = []
        var epgURL: URL?
        var skipped = 0
        var pendingTitle: String?
        var pendingAttributes: [String: String] = [:]
        var pendingGroup: String?
        var seenIDs = Set<String>()
        var counter = 0

        for rawLine in data.split(separator: 0x0A, omittingEmptySubsequences: true) {
            var line = String(decoding: rawLine, as: UTF8.self).trimmed
            if line.hasPrefix("\u{FEFF}") {
                line.removeFirst()
            }
            guard !line.isEmpty else { continue }

            if line.hasPrefix("#EXTM3U") {
                let headerAttributes = M3UParser.attributes(in: Substring(line))
                if let raw = firstNonEmpty(headerAttributes["url-tvg"], headerAttributes["x-tvg-url"]),
                   let first = raw.split(separator: ",").first {
                    epgURL = URL.lenient(String(first))
                }
                continue
            }
            if line.hasPrefix("#EXTINF") {
                let parsed = M3UParser.parseExtInf(line)
                pendingAttributes = parsed.attributes
                pendingTitle = parsed.title
                continue
            }
            if line.hasPrefix("#EXTGRP:") {
                pendingGroup = String(line.dropFirst("#EXTGRP:".count)).trimmed
                continue
            }
            if line.hasPrefix("#") {
                continue
            }

            // Une ligne d'adresse termine l'entrée en cours.
            defer {
                pendingTitle = nil
                pendingAttributes = [:]
                pendingGroup = nil
            }
            guard let url = URL.lenient(line) else { continue }
            if M3UParser.isVOD(url) {
                skipped += 1
                continue
            }
            counter += 1
            let name = firstNonEmpty(pendingTitle, pendingAttributes["tvg-name"]) ?? "Chaîne \(counter)"
            let group = firstNonEmpty(pendingAttributes["group-title"], pendingGroup) ?? "Sans groupe"
            var id = "m" + StableHash.hex(url.absoluteString)
            if seenIDs.contains(id) {
                id += "-\(counter)"
            }
            seenIDs.insert(id)
            channels.append(Channel(
                id: id,
                name: name,
                group: group,
                logoURL: URL.lenient(pendingAttributes["tvg-logo"]),
                streamURL: url,
                epgID: Channel.normalizeEPGID(pendingAttributes["tvg-id"]),
                number: Int(pendingAttributes["tvg-chno"] ?? "") ?? counter,
                xtreamStreamID: nil
            ))
        }
        return M3UParseResult(channels: channels, epgURL: epgURL, skippedVOD: skipped)
    }

    /// Sépare « #EXTINF:-1 tvg-id="…" group-title="…",Nom de la chaîne » en attributs + nom.
    static func parseExtInf(_ line: String) -> (attributes: [String: String], title: String) {
        guard let colon = line.firstIndex(of: ":") else { return ([:], "") }
        let body = line[line.index(after: colon)...]
        var inQuotes = false
        var separator: String.Index?
        var index = body.startIndex
        while index < body.endIndex {
            let character = body[index]
            if character == "\"" {
                inQuotes.toggle()
            } else if character == "," && !inQuotes {
                separator = index
                break
            }
            index = body.index(after: index)
        }
        guard let comma = separator else {
            return (M3UParser.attributes(in: body), "")
        }
        let title = String(body[body.index(after: comma)...]).trimmed
        return (M3UParser.attributes(in: body[body.startIndex..<comma]), title)
    }

    /// Lit les paires clé="valeur" d'une ligne #EXTINF ou #EXTM3U.
    static func attributes(in raw: Substring) -> [String: String] {
        let text = String(raw)
        var result: [String: String] = [:]
        var searchStart = text.startIndex
        while searchStart < text.endIndex,
              let marker = text.range(of: "=\"", range: searchStart..<text.endIndex) {
            var keyStart = marker.lowerBound
            while keyStart > text.startIndex {
                let previous = text.index(before: keyStart)
                let character = text[previous]
                if character == " " || character == "\t" || character == "," {
                    break
                }
                keyStart = previous
            }
            let key = text[keyStart..<marker.lowerBound].lowercased()
            let valueStart = marker.upperBound
            guard let valueEnd = text[valueStart...].firstIndex(of: "\"") else { break }
            if !key.isEmpty {
                result[key] = String(text[valueStart..<valueEnd])
            }
            searchStart = text.index(after: valueEnd)
        }
        return result
    }

    static func isVOD(_ url: URL) -> Bool {
        let path = url.path.lowercased()
        if path.contains("/movie/") || path.contains("/series/") {
            return true
        }
        let videoExtensions: Set<String> = ["mp4", "mkv", "avi", "mov", "m4v", "wmv", "flv", "webm", "mpg", "mpeg"]
        return videoExtensions.contains(url.pathExtension.lowercased())
    }
}

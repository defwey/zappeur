import Foundation

/// Liste des playlists (sans les mots de passe, qui sont dans le trousseau).
enum PlaylistStore {
    private static let key = "playlists.v1"

    static func load() -> [PlaylistConfig] {
        guard let data = UserDefaults.standard.data(forKey: key),
              let playlists = try? JSONDecoder().decode([PlaylistConfig].self, from: data) else { return [] }
        return playlists
    }

    static func save(_ playlists: [PlaylistConfig]) {
        guard let data = try? JSONEncoder().encode(playlists) else { return }
        UserDefaults.standard.set(data, forKey: key)
    }
}

struct CachedPlaylist: Codable {
    var savedAt: Date
    var channels: [Channel]
    var epgURL: URL?
}

/// Copie locale de la liste des chaînes : l'appli s'ouvre instantanément, puis se met à jour.
enum ChannelCache {
    private static func file(for id: UUID) -> URL {
        let directory = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
        return directory.appendingPathComponent("channels-\(id.uuidString).json")
    }

    static func load(for id: UUID) -> CachedPlaylist? {
        guard let data = try? Data(contentsOf: file(for: id)) else { return nil }
        return try? JSONDecoder().decode(CachedPlaylist.self, from: data)
    }

    static func save(_ playlist: CachedPlaylist, for id: UUID) {
        guard let data = try? JSONEncoder().encode(playlist) else { return }
        try? data.write(to: file(for: id), options: .atomic)
    }

    static func remove(for id: UUID) {
        try? FileManager.default.removeItem(at: file(for: id))
    }
}

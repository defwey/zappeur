import Foundation

struct XtreamAccount {
    var status: String
    var expiry: Date?
    var maxConnections: Int?
    var activeConnections: Int?
    var allowedFormats: [String]

    /// Le serveur accepte-t-il le HLS (m3u8) ? Si la liste est vide, on suppose que oui.
    var supportsHLS: Bool {
        allowedFormats.isEmpty || allowedFormats.contains { $0.lowercased() == "m3u8" }
    }

    var summary: String {
        var parts: [String] = ["Connexion réussie"]
        if let expiry = expiry {
            parts.append("abonnement valable jusqu'au \(expiry.formatted(date: .long, time: .omitted))")
        } else {
            parts.append("abonnement sans date d'expiration")
        }
        if let limit = maxConnections {
            parts.append(limit > 1 ? "\(limit) connexions simultanées" : "1 connexion à la fois")
        }
        return parts.joined(separator: " · ")
    }
}

/// Client de l'API Xtream Codes (player_api.php).
enum XtreamAPI {
    // MARK: - Adresses

    /// « exemple.com:8080/ » ou « http://exemple.com:8080/get.php?… » → « http://exemple.com:8080 ».
    static func normalizedBase(_ raw: String) -> URL? {
        var text = raw.trimmed
        guard !text.isEmpty else { return nil }
        let lower = text.lowercased()
        if !lower.hasPrefix("http://") && !lower.hasPrefix("https://") {
            text = "http://" + text
        }
        guard var components = URLComponents(string: text), components.host != nil else { return nil }
        var path = components.path
        for suffix in ["/player_api.php", "/get.php", "/xmltv.php", "/panel_api.php"] where path.lowercased().hasSuffix(suffix) {
            path = String(path.dropLast(suffix.count))
        }
        while path.hasSuffix("/") {
            path.removeLast()
        }
        components.path = path
        components.query = nil
        components.fragment = nil
        return components.url
    }

    static func apiURL(server: String, username: String, password: String,
                       action: String? = nil, extra: [URLQueryItem] = []) throws -> URL {
        var items: [URLQueryItem] = []
        if let action = action {
            items.append(URLQueryItem(name: "action", value: action))
        }
        items.append(contentsOf: extra)
        return try endpoint("player_api.php", server: server, username: username, password: password, extra: items)
    }

    static func xmltvURL(server: String, username: String, password: String) -> URL? {
        try? endpoint("xmltv.php", server: server, username: username, password: password, extra: [])
    }

    private static func endpoint(_ name: String, server: String, username: String, password: String,
                                 extra: [URLQueryItem]) throws -> URL {
        guard let base = normalizedBase(server),
              var components = URLComponents(url: base.appendingPathComponent(name), resolvingAgainstBaseURL: false) else {
            throw AppError.invalidURL
        }
        components.queryItems = [
            URLQueryItem(name: "username", value: username),
            URLQueryItem(name: "password", value: password)
        ] + extra
        // URLComponents laisse passer « + », que le serveur (PHP) lirait comme un espace.
        components.percentEncodedQuery = components.percentEncodedQuery?.replacingOccurrences(of: "+", with: "%2B")
        guard let url = components.url else { throw AppError.invalidURL }
        return url
    }

    static func streamURL(base: URL, username: String, password: String, streamID: Int, fileExtension: String) -> URL? {
        let user = username.addingPercentEncoding(withAllowedCharacters: .urlPathSegmentAllowed) ?? username
        let pass = password.addingPercentEncoding(withAllowedCharacters: .urlPathSegmentAllowed) ?? password
        return URL(string: "\(base.absoluteString)/live/\(user)/\(pass)/\(streamID).\(fileExtension)")
    }

    /// Reconnaît un lien M3U Xtream (get.php?username=…&password=…) pour proposer le mode Xtream.
    static func credentials(fromM3U raw: String) -> (server: String, username: String, password: String)? {
        guard let url = URL.lenient(raw),
              url.path.lowercased().hasSuffix("get.php"),
              let components = URLComponents(url: url, resolvingAgainstBaseURL: false) else { return nil }
        let items = components.queryItems ?? []
        guard let user = items.first(where: { $0.name == "username" })?.value, !user.isEmpty,
              let pass = items.first(where: { $0.name == "password" })?.value else { return nil }
        var base = URLComponents()
        base.scheme = components.scheme
        base.host = components.host
        base.port = components.port
        guard let server = base.url?.absoluteString else { return nil }
        return (server, user, pass)
    }

    // MARK: - Requêtes

    static func authenticate(server: String, username: String, password: String) async throws -> XtreamAccount {
        let url = try apiURL(server: server, username: username, password: password)
        let json = try await Net.json(from: url)
        guard let root = json as? [String: Any], let info = root["user_info"] as? [String: Any] else {
            throw AppError.badResponse
        }
        guard info.int("auth") == 1 else { throw AppError.invalidCredentials }
        let status = info.string("status") ?? "Active"
        guard status.lowercased() == "active" else { throw AppError.accountInactive(status) }
        var expiry: Date?
        if let timestamp = info.double("exp_date"), timestamp > 0 {
            expiry = Date(timeIntervalSince1970: timestamp)
        }
        var formats: [String] = []
        if let list = info["allowed_output_formats"] as? [Any] {
            formats = list.map { "\($0)" }
        }
        return XtreamAccount(status: status,
                             expiry: expiry,
                             maxConnections: info.int("max_connections"),
                             activeConnections: info.int("active_cons"),
                             allowedFormats: formats)
    }

    static func liveChannels(server: String, username: String, password: String) async throws -> [Channel] {
        let account = try await authenticate(server: server, username: username, password: password)
        guard let base = normalizedBase(server) else { throw AppError.invalidURL }
        let categoriesURL = try apiURL(server: server, username: username, password: password, action: "get_live_categories")
        let streamsURL = try apiURL(server: server, username: username, password: password, action: "get_live_streams")

        async let categoriesJSON = Net.json(from: categoriesURL)
        async let streamsJSON = Net.json(from: streamsURL)
        let (categoriesValue, streamsValue) = try await (categoriesJSON, streamsJSON)

        // Catégories : nom et ordre d'affichage choisis par le fournisseur.
        var categoryNames: [String: String] = [:]
        var categoryOrder: [String: Int] = [:]
        let categories = (categoriesValue as? [[String: Any]]) ?? []
        for (index, item) in categories.enumerated() {
            guard let id = item.string("category_id") else { continue }
            categoryNames[id] = item.string("category_name")
            categoryOrder[id] = index
        }

        let fileExtension = account.supportsHLS ? "m3u8" : "ts"
        let streams = (streamsValue as? [[String: Any]]) ?? []
        var entries: [(channel: Channel, order: Int, position: Int)] = []
        entries.reserveCapacity(streams.count)
        var seen = Set<Int>()
        for (position, item) in streams.enumerated() {
            guard let streamID = item.int("stream_id"), seen.insert(streamID).inserted,
                  let url = streamURL(base: base, username: username, password: password,
                                      streamID: streamID, fileExtension: fileExtension) else { continue }
            var categoryID = item.string("category_id") ?? ""
            if categoryID.isEmpty, let ids = item["category_ids"] as? [Any], let first = ids.first {
                categoryID = "\(first)"
            }
            let channel = Channel(
                id: "x\(streamID)",
                name: firstNonEmpty(item.string("name")) ?? "Chaîne \(streamID)",
                group: firstNonEmpty(categoryNames[categoryID]) ?? "Sans groupe",
                logoURL: URL.lenient(item.string("stream_icon")),
                streamURL: url,
                epgID: Channel.normalizeEPGID(item.string("epg_channel_id")),
                number: item.int("num"),
                xtreamStreamID: streamID
            )
            entries.append((channel: channel, order: categoryOrder[categoryID] ?? Int.max, position: position))
        }
        entries.sort { lhs, rhs in
            lhs.order != rhs.order ? lhs.order < rhs.order : lhs.position < rhs.position
        }
        return entries.map { $0.channel }
    }

    /// Guide TV « court » d'une chaîne (quand le guide XMLTV ne la couvre pas).
    static func shortEPG(server: String, username: String, password: String,
                         streamID: Int, limit: Int = 12) async throws -> [Programme] {
        let url = try apiURL(server: server, username: username, password: password, action: "get_short_epg", extra: [
            URLQueryItem(name: "stream_id", value: String(streamID)),
            URLQueryItem(name: "limit", value: String(limit))
        ])
        let json = try await Net.json(from: url)
        guard let root = json as? [String: Any],
              let listings = root["epg_listings"] as? [[String: Any]] else { return [] }
        var programmes: [Programme] = []
        for item in listings {
            guard let start = item.double("start_timestamp"),
                  let stop = item.double("stop_timestamp"), stop > start else { continue }
            let title = decodeBase64(item.string("title"))
            programmes.append(Programme(
                title: title.isEmpty ? "Sans titre" : title,
                summary: decodeBase64(item.string("description")),
                start: Date(timeIntervalSince1970: start),
                end: Date(timeIntervalSince1970: stop)
            ))
        }
        return Programme.normalized(programmes)
    }

    /// Les titres du guide court sont encodés en base64 par la plupart des serveurs.
    static func decodeBase64(_ text: String?) -> String {
        guard let text = text?.trimmed, !text.isEmpty else { return "" }
        if let data = Data(base64Encoded: text), let decoded = String(data: data, encoding: .utf8) {
            return decoded.trimmed
        }
        return text
    }
}

import Foundation

/// Téléchargement (avec cache de 12 h) et lecture du guide TV XMLTV.
enum EPGLoader {
    static let maxAge: TimeInterval = 12 * 3600

    static func cacheFile(for key: String) -> URL {
        let directory = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
        return directory.appendingPathComponent("epg-\(key).xml")
    }

    static func removeCache(for key: String) {
        try? FileManager.default.removeItem(at: cacheFile(for: key))
    }

    static func load(url: URL, cacheKey: String, force: Bool, wanted: Set<String>) async throws -> [String: [Programme]] {
        let fileManager = FileManager.default
        let file = cacheFile(for: cacheKey)

        if force || !isFresh(file) {
            let temporary = try await Net.download(from: url)
            defer { try? fileManager.removeItem(at: temporary) }
            let staging = file.deletingPathExtension().appendingPathExtension("tmp")
            try? fileManager.removeItem(at: staging)
            if Gzip.isGzip(temporary) {
                try Gzip.decompress(temporary, to: staging)
            } else {
                try fileManager.moveItem(at: temporary, to: staging)
            }
            try? fileManager.removeItem(at: file)
            try fileManager.moveItem(at: staging, to: file)
        }

        let now = Date()
        let parser = XMLTVParser(wanted: wanted,
                                 windowStart: now.addingTimeInterval(-3 * 3600),
                                 windowEnd: now.addingTimeInterval(36 * 3600))
        guard let result = parser.parse(fileURL: file) else {
            removeCache(for: cacheKey)
            throw AppError.invalidEPG
        }
        return result
    }

    private static func isFresh(_ file: URL) -> Bool {
        guard let attributes = try? FileManager.default.attributesOfItem(atPath: file.path),
              let modified = attributes[.modificationDate] as? Date else { return false }
        return Date().timeIntervalSince(modified) < maxAge
    }
}

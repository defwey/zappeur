import Foundation
import Compression

/// Décompression des guides TV livrés en .xml.gz, morceau par morceau (sans tout charger en mémoire).
enum Gzip {
    static func isGzip(_ fileURL: URL) -> Bool {
        guard let handle = try? FileHandle(forReadingFrom: fileURL) else { return false }
        defer { try? handle.close() }
        guard let header = try? handle.read(upToCount: 2), header.count == 2 else { return false }
        let bytes = [UInt8](header)
        return bytes[0] == 0x1f && bytes[1] == 0x8b
    }

    static func decompress(_ source: URL, to destination: URL) throws {
        let size = try fileSize(source)
        let input = try FileHandle(forReadingFrom: source)
        defer { try? input.close() }

        // En-tête gzip (RFC 1952) : 10 octets + champs facultatifs.
        guard let headerData = try input.read(upToCount: 10), headerData.count == 10 else {
            throw AppError.invalidEPG
        }
        let header = [UInt8](headerData)
        guard header[0] == 0x1f, header[1] == 0x8b, header[2] == 8 else { throw AppError.invalidEPG }
        let flags = header[3]
        var offset: UInt64 = 10
        if flags & 0x04 != 0 { // FEXTRA
            try input.seek(toOffset: offset)
            guard let extraData = try input.read(upToCount: 2), extraData.count == 2 else {
                throw AppError.invalidEPG
            }
            let extra = [UInt8](extraData)
            offset += 2 + UInt64(extra[0]) + (UInt64(extra[1]) << 8)
        }
        if flags & 0x08 != 0 { // FNAME
            offset = try skipZeroTerminatedField(input, from: offset)
        }
        if flags & 0x10 != 0 { // FCOMMENT
            offset = try skipZeroTerminatedField(input, from: offset)
        }
        if flags & 0x02 != 0 { // FHCRC
            offset += 2
        }
        guard size > offset + 8 else { throw AppError.invalidEPG }
        let end = size - 8 // les 8 derniers octets : CRC32 + taille d'origine

        FileManager.default.createFile(atPath: destination.path, contents: nil)
        let output = try FileHandle(forWritingTo: destination)
        defer { try? output.close() }

        // « .zlib » correspond au DEFLATE brut, c'est-à-dire le contenu d'un fichier gzip.
        let filter = try OutputFilter(.decompress, using: .zlib) { (chunk: Data?) in
            if let chunk = chunk {
                try output.write(contentsOf: chunk)
            }
        }
        try input.seek(toOffset: offset)
        var position = offset
        while position < end {
            let count = Int(min(UInt64(1 << 20), end - position))
            guard let chunk = try input.read(upToCount: count), !chunk.isEmpty else { break }
            try filter.write(chunk)
            position += UInt64(chunk.count)
        }
        try filter.finalize()
    }

    private static func fileSize(_ url: URL) throws -> UInt64 {
        let attributes = try FileManager.default.attributesOfItem(atPath: url.path)
        return (attributes[.size] as? NSNumber)?.uint64Value ?? 0
    }

    private static func skipZeroTerminatedField(_ handle: FileHandle, from offset: UInt64) throws -> UInt64 {
        try handle.seek(toOffset: offset)
        var position = offset
        while true {
            guard let chunk = try handle.read(upToCount: 512), !chunk.isEmpty else {
                throw AppError.invalidEPG
            }
            if let zero = chunk.firstIndex(of: 0) {
                return position + UInt64(zero - chunk.startIndex) + 1
            }
            position += UInt64(chunk.count)
        }
    }
}

import Foundation

/// Le lecteur d'Apple (AVPlayer) lit le HLS (.m3u8) mais pas le MPEG-TS brut (.ts).
/// La plupart des serveurs Xtream Codes proposent les deux : on essaie d'abord la version HLS,
/// puis l'adresse d'origine.
enum StreamURLResolver {
    static func candidates(for url: URL, preferHLS: Bool) -> [URL] {
        guard preferHLS, let hls = hlsVariant(of: url), hls != url else { return [url] }
        return [hls, url]
    }

    static func hlsVariant(of url: URL) -> URL? {
        let fileExtension = url.pathExtension.lowercased()
        guard fileExtension != "m3u8",
              var components = URLComponents(url: url, resolvingAgainstBaseURL: false) else { return nil }
        let parts = url.pathComponents.filter { $0 != "/" }

        // http://serveur/live/user/pass/123.ts → http://serveur/live/user/pass/123.m3u8
        if fileExtension == "ts", let last = parts.last {
            var newParts = Array(parts.dropLast())
            newParts.append(String(last.dropLast(3)) + ".m3u8")
            // http://serveur/user/pass/123.ts → http://serveur/live/user/pass/123.m3u8
            if newParts.count == 3 {
                newParts.insert("live", at: 0)
            }
            components.path = "/" + newParts.joined(separator: "/")
            return components.url
        }

        // Format Xtream sans extension : http://serveur/user/pass/123
        if fileExtension.isEmpty, parts.count == 3, Int(parts[2]) != nil {
            components.path = "/live/" + parts.joined(separator: "/") + ".m3u8"
            return components.url
        }
        return nil
    }
}

import Foundation

enum AppError: LocalizedError {
    case invalidURL
    case invalidCredentials
    case accountInactive(String)
    case badResponse
    case emptyPlaylist
    case http(Int)
    case invalidEPG

    var errorDescription: String? {
        switch self {
        case .invalidURL:
            return "Adresse invalide. Vérifie le lien ou l'adresse du serveur."
        case .invalidCredentials:
            return "Identifiants refusés par le serveur."
        case .accountInactive(let status):
            return "L'abonnement n'est pas actif (état : \(status))."
        case .badResponse:
            return "Réponse inattendue du serveur."
        case .emptyPlaylist:
            return "La playlist ne contient aucune chaîne en direct."
        case .http(let code):
            return "Le serveur a répondu avec l'erreur \(code)."
        case .invalidEPG:
            return "Le fichier du guide TV est illisible."
        }
    }
}

enum Net {
    static let session: URLSession = {
        let configuration = URLSessionConfiguration.default
        configuration.timeoutIntervalForRequest = 30
        configuration.timeoutIntervalForResource = 900
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        return URLSession(configuration: configuration)
    }()

    static func data(from url: URL) async throws -> Data {
        let (payload, response) = try await session.data(from: url)
        try check(response)
        return payload
    }

    static func json(from url: URL) async throws -> Any {
        let payload = try await Net.data(from: url)
        do {
            return try JSONSerialization.jsonObject(with: payload, options: [.fragmentsAllowed])
        } catch {
            throw AppError.badResponse
        }
    }

    /// Télécharge dans un fichier temporaire (adapté aux gros guides TV).
    static func download(from url: URL) async throws -> URL {
        let (temporaryURL, response) = try await session.download(from: url)
        try check(response)
        return temporaryURL
    }

    private static func check(_ response: URLResponse) throws {
        if let http = response as? HTTPURLResponse, !(200..<300).contains(http.statusCode) {
            throw AppError.http(http.statusCode)
        }
    }
}

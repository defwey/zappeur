import Foundation
#if canImport(FoundationXML)
import FoundationXML
#endif

/// Lecture en continu (sans tout charger en mémoire) d'un guide TV au format XMLTV.
/// Ne garde que les chaînes de la playlist et une fenêtre de temps autour de maintenant.
final class XMLTVParser: NSObject, XMLParserDelegate {
    private enum Capture {
        case idle
        case title
        case desc
    }

    private let wanted: Set<String>
    private let windowStart: Date
    private let windowEnd: Date
    private var result: [String: [Programme]] = [:]

    private var currentKey: String?
    private var currentStart = Date.distantPast
    private var currentEnd = Date.distantPast
    private var currentTitle: String?
    private var currentDesc: String?
    private var capture: Capture = .idle
    private var buffer = ""

    init(wanted: Set<String>, windowStart: Date, windowEnd: Date) {
        self.wanted = wanted
        self.windowStart = windowStart
        self.windowEnd = windowEnd
        super.init()
    }

    func parse(fileURL: URL) -> [String: [Programme]]? {
        guard let stream = InputStream(url: fileURL) else { return nil }
        let parser = XMLParser(stream: stream)
        parser.delegate = self
        parser.shouldResolveExternalEntities = false
        let success = parser.parse()
        if !success && result.isEmpty {
            return nil
        }
        return result.mapValues { Programme.normalized($0) }
    }

    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?,
                qualifiedName qName: String?, attributes attributeDict: [String: String] = [:]) {
        switch elementName {
        case "programme":
            currentKey = nil
            currentTitle = nil
            currentDesc = nil
            capture = .idle
            guard let key = Channel.normalizeEPGID(attributeDict["channel"]),
                  wanted.isEmpty || wanted.contains(key),
                  let startText = attributeDict["start"],
                  let start = XMLTVDate.parse(startText) else { return }
            var end = start.addingTimeInterval(3600)
            if let stopText = attributeDict["stop"], let stop = XMLTVDate.parse(stopText) {
                end = stop
            }
            guard end > start, end > windowStart, start < windowEnd else { return }
            currentKey = key
            currentStart = start
            currentEnd = end
        case "title":
            if currentKey != nil, currentTitle == nil {
                capture = .title
                buffer = ""
            }
        case "desc":
            if currentKey != nil, currentDesc == nil {
                capture = .desc
                buffer = ""
            }
        default:
            break
        }
    }

    func parser(_ parser: XMLParser, foundCharacters string: String) {
        if capture != .idle {
            buffer += string
        }
    }

    func parser(_ parser: XMLParser, foundCDATA CDATABlock: Data) {
        if capture != .idle, let text = String(data: CDATABlock, encoding: .utf8) {
            buffer += text
        }
    }

    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?,
                qualifiedName qName: String?) {
        switch elementName {
        case "title":
            if capture == .title {
                currentTitle = buffer.trimmed
                capture = .idle
            }
        case "desc":
            if capture == .desc {
                currentDesc = buffer.trimmed
                capture = .idle
            }
        case "programme":
            if let key = currentKey {
                let programme = Programme(title: firstNonEmpty(currentTitle) ?? "Sans titre",
                                          summary: currentDesc ?? "",
                                          start: currentStart,
                                          end: currentEnd)
                result[key, default: []].append(programme)
            }
            currentKey = nil
            capture = .idle
        default:
            break
        }
    }
}

/// Dates XMLTV : « 20261118200000 +0100 » (secondes et fuseau horaire facultatifs).
/// Décodage manuel, bien plus rapide qu'un DateFormatter sur des centaines de milliers de lignes.
enum XMLTVDate {
    static func parse(_ text: String) -> Date? {
        let bytes = Array(text.utf8)
        var digits: [Int] = []
        digits.reserveCapacity(14)
        var index = 0
        while index < bytes.count, digits.count < 14, bytes[index] >= 48, bytes[index] <= 57 {
            digits.append(Int(bytes[index]) - 48)
            index += 1
        }
        guard digits.count >= 12 else { return nil }

        func number(_ start: Int, _ length: Int) -> Int {
            var value = 0
            for position in start..<(start + length) {
                value = value * 10 + digits[position]
            }
            return value
        }

        let year = number(0, 4)
        let month = number(4, 2)
        let day = number(6, 2)
        let hour = number(8, 2)
        let minute = number(10, 2)
        let second = digits.count >= 14 ? number(12, 2) : 0
        guard (1...12).contains(month), (1...31).contains(day), hour < 24, minute < 60, second < 61 else {
            return nil
        }

        // Ignore d'éventuels chiffres en trop, puis les espaces avant le fuseau horaire.
        while index < bytes.count, bytes[index] >= 48, bytes[index] <= 57 {
            index += 1
        }
        while index < bytes.count, bytes[index] == 32 {
            index += 1
        }
        var offset = 0
        if index < bytes.count, bytes[index] == 43 || bytes[index] == 45 {
            let sign = bytes[index] == 45 ? -1 : 1
            var zone: [Int] = []
            var cursor = index + 1
            while cursor < bytes.count, zone.count < 4, bytes[cursor] >= 48, bytes[cursor] <= 57 {
                zone.append(Int(bytes[cursor]) - 48)
                cursor += 1
            }
            if zone.count == 4 {
                offset = sign * ((zone[0] * 10 + zone[1]) * 3600 + (zone[2] * 10 + zone[3]) * 60)
            }
        }

        let days = daysFromCivil(year: year, month: month, day: day)
        let seconds = days * 86_400 + hour * 3600 + minute * 60 + second - offset
        return Date(timeIntervalSince1970: TimeInterval(seconds))
    }

    /// Nombre de jours depuis le 1er janvier 1970 (algorithme de Howard Hinnant).
    static func daysFromCivil(year: Int, month: Int, day: Int) -> Int {
        let y = month <= 2 ? year - 1 : year
        let era = (y >= 0 ? y : y - 399) / 400
        let yearOfEra = y - era * 400
        let shiftedMonth = (month + 9) % 12
        let dayOfYear = (153 * shiftedMonth + 2) / 5 + day - 1
        let dayOfEra = yearOfEra * 365 + yearOfEra / 4 - yearOfEra / 100 + dayOfYear
        return era * 146_097 + dayOfEra - 719_468
    }
}

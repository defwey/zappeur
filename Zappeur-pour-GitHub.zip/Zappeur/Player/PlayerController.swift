import AVFoundation
import AVKit
import Combine

/// Pilote la lecture : essaie les variantes d'adresse du flux (HLS puis d'origine) et expose l'état à l'écran.
@MainActor
final class PlayerController: ObservableObject {
    enum PlaybackState: Equatable {
        case idle
        case loading
        case playing
        case failed(String)
    }

    let player: AVPlayer
    @Published private(set) var state: PlaybackState = .idle
    @Published private(set) var currentChannelID: String? = nil
    @Published var isPictureInPictureActive = false
    /// Garde le lecteur en vie pendant le Picture-in-Picture, même si l'écran du lecteur a été fermé.
    var retainedPlayerViewController: AVPlayerViewController?
    var preferHLS = true

    private var candidates: [URL] = []
    private var candidateIndex = 0
    private var attemptID = 0
    private var hasStartedPlaying = false
    private var lastError: String?
    private var statusObservation: NSKeyValueObservation?
    private var timeControlObservation: NSKeyValueObservation?
    private var timeoutTask: Task<Void, Never>?

    init() {
        let player = AVPlayer()
        player.automaticallyWaitsToMinimizeStalling = true
        self.player = player
        timeControlObservation = player.observe(\.timeControlStatus, options: [.new]) { [weak self] observed, _ in
            let status = observed.timeControlStatus
            guard let controller = self else { return }
            Task { @MainActor in
                controller.timeControlStatusChanged(status)
            }
        }
    }

    func play(_ channel: Channel) {
        currentChannelID = channel.id
        candidates = StreamURLResolver.candidates(for: channel.streamURL, preferHLS: preferHLS)
        candidateIndex = 0
        lastError = nil
        startAttempt()
    }

    func retry() {
        guard !candidates.isEmpty else { return }
        candidateIndex = 0
        lastError = nil
        startAttempt()
    }

    func stop() {
        attemptID += 1
        timeoutTask?.cancel()
        timeoutTask = nil
        statusObservation = nil
        player.pause()
        player.replaceCurrentItem(with: nil)
        candidates = []
        currentChannelID = nil
        state = .idle
    }

    private func startAttempt() {
        attemptID += 1
        let attempt = attemptID
        timeoutTask?.cancel()
        statusObservation = nil
        hasStartedPlaying = false

        guard candidateIndex < candidates.count else {
            player.replaceCurrentItem(with: nil)
            var message = "Impossible de lire cette chaîne. Le flux est peut-être hors ligne, ou dans un format que le lecteur d'Apple ne sait pas lire (MPEG-TS, MKV)."
            if let lastError = lastError {
                message += "\n\n" + lastError
            }
            state = .failed(message)
            return
        }

        state = .loading
        let item = AVPlayerItem(url: candidates[candidateIndex])
        statusObservation = item.observe(\.status, options: [.new]) { [weak self] observed, _ in
            let status = observed.status
            let errorText = observed.error?.localizedDescription
            guard let controller = self else { return }
            Task { @MainActor in
                controller.itemStatusChanged(status, error: errorText, attempt: attempt)
            }
        }
        player.replaceCurrentItem(with: item)
        player.play()

        // Si rien ne démarre au bout de 20 s, on passe à la variante suivante.
        timeoutTask = Task { [weak self] in
            try? await Task.sleep(nanoseconds: 20_000_000_000)
            guard !Task.isCancelled else { return }
            self?.attemptTimedOut(attempt)
        }
    }

    private func itemStatusChanged(_ status: AVPlayerItem.Status, error: String?, attempt: Int) {
        guard attempt == attemptID else { return }
        switch status {
        case .failed:
            lastError = error
            if hasStartedPlaying {
                timeoutTask?.cancel()
                var message = "La lecture s'est interrompue."
                if let error = error {
                    message += "\n\n" + error
                }
                state = .failed(message)
            } else {
                candidateIndex += 1
                startAttempt()
            }
        case .readyToPlay:
            if player.timeControlStatus == .playing {
                markPlaying()
            }
        default:
            break
        }
    }

    private func timeControlStatusChanged(_ status: AVPlayer.TimeControlStatus) {
        guard player.currentItem != nil, status == .playing else { return }
        markPlaying()
    }

    private func markPlaying() {
        hasStartedPlaying = true
        timeoutTask?.cancel()
        if state != .playing {
            state = .playing
        }
    }

    private func attemptTimedOut(_ attempt: Int) {
        guard attempt == attemptID, !hasStartedPlaying else { return }
        lastError = "Délai d'attente dépassé."
        candidateIndex += 1
        startAttempt()
    }
}

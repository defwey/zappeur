import SwiftUI
import UIKit
import AVKit

/// Lecteur vidéo natif d'Apple (commandes, AirPlay, Picture-in-Picture) intégré dans SwiftUI.
struct PlayerViewControllerRepresentable: UIViewControllerRepresentable {
    let controller: PlayerController

    func makeCoordinator() -> Coordinator {
        Coordinator(controller: controller)
    }

    func makeUIViewController(context: Context) -> AVPlayerViewController {
        let viewController = AVPlayerViewController()
        viewController.player = controller.player
        viewController.allowsPictureInPicturePlayback = true
        viewController.canStartPictureInPictureAutomaticallyFromInline = true
        viewController.entersFullScreenWhenPlaybackBegins = false
        viewController.exitsFullScreenWhenPlaybackEnds = false
        viewController.videoGravity = .resizeAspect
        viewController.view.backgroundColor = .black
        viewController.delegate = context.coordinator
        return viewController
    }

    func updateUIViewController(_ viewController: AVPlayerViewController, context: Context) {
        if viewController.player !== controller.player {
            viewController.player = controller.player
        }
    }

    final class Coordinator: NSObject, AVPlayerViewControllerDelegate {
        private let controller: PlayerController

        init(controller: PlayerController) {
            self.controller = controller
        }

        func playerViewControllerWillStartPictureInPicture(_ playerViewController: AVPlayerViewController) {
            let controller = self.controller
            Task { @MainActor in
                controller.isPictureInPictureActive = true
                controller.retainedPlayerViewController = playerViewController
            }
        }

        func playerViewControllerDidStopPictureInPicture(_ playerViewController: AVPlayerViewController) {
            let controller = self.controller
            Task { @MainActor in
                controller.isPictureInPictureActive = false
                controller.retainedPlayerViewController = nil
            }
        }

        func playerViewController(_ playerViewController: AVPlayerViewController,
                                  restoreUserInterfaceForPictureInPictureStopWithCompletionHandler completionHandler: @escaping (Bool) -> Void) {
            completionHandler(true)
        }
    }
}

import SwiftUI

enum PlayerTab: Hashable {
    case guide
    case channels
}

/// Écran de lecture : vidéo en haut, programme en cours, guide TV et liste pour zapper.
/// En tournant le téléphone (paysage), la vidéo occupe tout l'écran.
@MainActor
struct PlayerScreen: View {
    @EnvironmentObject private var model: AppModel
    @ObservedObject private var playback: PlayerController
    @Environment(\.dismiss) private var dismiss
    @Environment(\.verticalSizeClass) private var verticalSizeClass

    private let context: [Channel]
    @State private var current: Channel
    @State private var tab: PlayerTab = .guide

    init(session: PlayerSession, playback: PlayerController) {
        _playback = ObservedObject(wrappedValue: playback)
        context = session.context
        _current = State(initialValue: session.channel)
    }

    private var isLandscape: Bool {
        verticalSizeClass == .compact
    }

    var body: some View {
        GeometryReader { geometry in
            VStack(spacing: 0) {
                if !isLandscape {
                    topBar
                }
                videoArea
                    .frame(width: geometry.size.width, height: videoHeight(for: geometry.size))
                if !isLandscape {
                    infoPanel
                    tabPicker
                    tabContent
                }
            }
        }
        .background(Color.black.ignoresSafeArea())
        .ignoresSafeArea(.container, edges: isLandscape ? .all : [])
        .statusBarHidden(isLandscape)
        .persistentSystemOverlays(isLandscape ? .hidden : .automatic)
        .onAppear {
            model.play(current)
        }
        .onDisappear {
            if !playback.isPictureInPictureActive {
                playback.stop()
            }
        }
    }

    private func videoHeight(for size: CGSize) -> CGFloat {
        if isLandscape {
            return size.height
        }
        return min(size.width * 9 / 16, size.height * 0.5)
    }

    // MARK: - Barre du haut

    private var favoriteLabel: String {
        model.isFavorite(current) ? "Retirer des favoris" : "Ajouter aux favoris"
    }

    private var topBar: some View {
        HStack(spacing: 12) {
            Button {
                dismiss()
            } label: {
                Image(systemName: "chevron.down")
                    .font(.title3.weight(.semibold))
                    .frame(width: 36, height: 36)
            }
            .accessibilityLabel("Fermer le lecteur")
            VStack(alignment: .leading, spacing: 1) {
                Text(current.name)
                    .font(.headline)
                    .lineLimit(1)
                Text(current.group)
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .lineLimit(1)
            }
            Spacer(minLength: 0)
            Button {
                model.toggleFavorite(current)
            } label: {
                Image(systemName: model.isFavorite(current) ? "star.fill" : "star")
                    .font(.title3)
                    .foregroundColor(model.isFavorite(current) ? .yellow : .primary)
                    .frame(width: 36, height: 36)
            }
            .accessibilityLabel(favoriteLabel)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 6)
        .foregroundColor(.primary)
    }

    // MARK: - Vidéo

    private var videoArea: some View {
        ZStack {
            Color.black
            PlayerViewControllerRepresentable(controller: playback)
            stateOverlay
        }
    }

    @ViewBuilder private var stateOverlay: some View {
        switch playback.state {
        case .loading:
            ProgressView()
                .controlSize(.large)
                .tint(.white)
                .allowsHitTesting(false)
        case .failed(let message):
            VStack(spacing: 12) {
                Image(systemName: "exclamationmark.triangle.fill")
                    .font(.largeTitle)
                    .foregroundColor(.yellow)
                Text(message)
                    .font(.callout)
                    .multilineTextAlignment(.center)
                    .foregroundColor(.white)
                Button("Réessayer") {
                    playback.retry()
                }
                .buttonStyle(.borderedProminent)
            }
            .padding(20)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color.black.opacity(0.85))
        case .idle, .playing:
            EmptyView()
        }
    }

    // MARK: - Programme en cours

    private var infoPanel: some View {
        let info = model.nowAndNext(for: current)
        return VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .center, spacing: 12) {
                ChannelLogo(url: current.logoURL, name: current.name)
                    .frame(width: 64, height: 46)
                VStack(alignment: .leading, spacing: 3) {
                    if let programme = info.current {
                        Text(programme.title)
                            .font(.headline)
                            .lineLimit(2)
                        Text(timeRange(programme))
                            .font(.caption)
                            .foregroundColor(.secondary)
                    } else {
                        Text(current.name)
                            .font(.headline)
                            .lineLimit(1)
                        Text("Aucune information de programme")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
                Spacer(minLength: 0)
                VStack(spacing: 4) {
                    Button {
                        step(-1)
                    } label: {
                        Image(systemName: "chevron.up")
                            .frame(width: 40, height: 30)
                    }
                    .accessibilityLabel("Chaîne précédente")
                    Button {
                        step(1)
                    } label: {
                        Image(systemName: "chevron.down")
                            .frame(width: 40, height: 30)
                    }
                    .accessibilityLabel("Chaîne suivante")
                }
                .font(.title3.weight(.semibold))
                .disabled(context.count < 2)
            }
            if let programme = info.current {
                ProgressView(value: programme.progress(at: model.now))
                    .tint(.accentColor)
            }
            if let next = info.next {
                Text("Ensuite à \(timeString(next.start)) : \(next.title)")
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .lineLimit(1)
            }
        }
        .padding(.horizontal)
        .padding(.top, 10)
    }

    // MARK: - Onglets Guide / Chaînes

    private var tabPicker: some View {
        Picker("Affichage", selection: $tab) {
            Text("Guide TV").tag(PlayerTab.guide)
            Text("Chaînes").tag(PlayerTab.channels)
        }
        .pickerStyle(.segmented)
        .padding(.horizontal)
        .padding(.vertical, 10)
    }

    @ViewBuilder private var tabContent: some View {
        switch tab {
        case .guide:
            guideList
        case .channels:
            channelList
        }
    }

    @ViewBuilder private var guideList: some View {
        let items = model.programmes(for: current).filter { $0.end > model.now }
        if items.isEmpty {
            VStack(spacing: 8) {
                Image(systemName: "calendar.badge.exclamationmark")
                    .font(.title)
                    .foregroundColor(.secondary)
                Text(emptyGuideMessage)
                    .font(.callout)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
            }
            .padding()
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        } else {
            List(items) { programme in
                ProgrammeRow(programme: programme, isLive: programme.contains(model.now))
            }
            .listStyle(.plain)
        }
    }

    private var emptyGuideMessage: String {
        switch model.epgStatus {
        case .loading:
            return "Chargement du guide TV…"
        case .failed(let message):
            return "Guide TV indisponible : \(message)"
        default:
            return "Aucun programme disponible pour cette chaîne."
        }
    }

    private var channelList: some View {
        ScrollViewReader { proxy in
            List(context) { channel in
                Button {
                    switchTo(channel)
                } label: {
                    ChannelRow(channel: channel,
                               isFavorite: model.isFavorite(channel),
                               nowNext: model.nowAndNext(for: channel),
                               date: model.now)
                }
                .buttonStyle(.plain)
                .listRowBackground(channel.id == current.id ? Color.accentColor.opacity(0.2) : Color.clear)
                .id(channel.id)
            }
            .listStyle(.plain)
            .onAppear {
                proxy.scrollTo(current.id, anchor: .center)
            }
        }
    }

    // MARK: - Zapping

    private func step(_ delta: Int) {
        guard !context.isEmpty else { return }
        let index = context.firstIndex { $0.id == current.id } ?? 0
        let target = (index + delta + context.count) % context.count
        switchTo(context[target])
    }

    private func switchTo(_ channel: Channel) {
        guard channel.id != current.id else { return }
        current = channel
        model.play(channel)
    }

    private func timeString(_ date: Date) -> String {
        date.formatted(date: .omitted, time: .shortened)
    }

    private func timeRange(_ programme: Programme) -> String {
        "\(timeString(programme.start)) – \(timeString(programme.end))"
    }
}

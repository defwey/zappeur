import SwiftUI

/// Une ligne de la liste : numéro, logo, nom, programme en cours et sa progression.
struct ChannelRow: View {
    let channel: Channel
    let isFavorite: Bool
    let nowNext: NowNext
    let date: Date

    var body: some View {
        HStack(spacing: 12) {
            Text(channel.number.map { String($0) } ?? "")
                .font(.caption.monospacedDigit())
                .foregroundColor(.secondary)
                .frame(width: 34, alignment: .trailing)
            ChannelLogo(url: channel.logoURL, name: channel.name)
                .frame(width: 56, height: 40)
            VStack(alignment: .leading, spacing: 4) {
                Text(channel.name)
                    .font(.body.weight(.medium))
                    .lineLimit(1)
                if let current = nowNext.current {
                    Text(current.title)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .lineLimit(1)
                    ProgressView(value: current.progress(at: date))
                        .tint(.accentColor)
                } else if let next = nowNext.next {
                    Text("À \(next.start.formatted(date: .omitted, time: .shortened)) : \(next.title)")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .lineLimit(1)
                }
            }
            Spacer(minLength: 0)
            if isFavorite {
                Image(systemName: "star.fill")
                    .font(.caption)
                    .foregroundColor(.yellow)
            }
        }
        .padding(.vertical, 4)
        .contentShape(Rectangle())
    }
}

/// Logo de la chaîne, ou ses initiales s'il n'y en a pas.
struct ChannelLogo: View {
    let url: URL?
    let name: String

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 6)
                .fill(Color.white.opacity(0.06))
            if let url = url {
                AsyncImage(url: url) { image in
                    image
                        .resizable()
                        .scaledToFit()
                        .padding(3)
                } placeholder: {
                    initials
                }
            } else {
                initials
            }
        }
    }

    private var initials: some View {
        Text(String(name.prefix(2)).uppercased())
            .font(.caption.bold())
            .foregroundColor(.secondary)
    }
}

/// Une ligne du guide TV.
struct ProgrammeRow: View {
    let programme: Programme
    let isLive: Bool

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Text(programme.start.formatted(date: .omitted, time: .shortened))
                .font(.subheadline.monospacedDigit())
                .foregroundColor(isLive ? .accentColor : .secondary)
                .frame(width: 56, alignment: .leading)
            VStack(alignment: .leading, spacing: 3) {
                HStack(spacing: 6) {
                    if isLive {
                        Text("EN DIRECT")
                            .font(.caption2.bold())
                            .padding(.horizontal, 5)
                            .padding(.vertical, 2)
                            .background(Capsule().fill(Color.red))
                            .foregroundColor(.white)
                    }
                    Text(programme.title)
                        .font(.subheadline.weight(isLive ? .semibold : .regular))
                        .lineLimit(2)
                }
                if !programme.summary.isEmpty {
                    Text(programme.summary)
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .lineLimit(3)
                }
            }
        }
        .padding(.vertical, 4)
    }
}

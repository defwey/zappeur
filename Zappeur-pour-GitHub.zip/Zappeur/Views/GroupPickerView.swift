import SwiftUI

/// Liste complète des groupes, avec recherche (pratique quand le fournisseur en propose des centaines).
@MainActor
struct GroupPickerView: View {
    @EnvironmentObject private var model: AppModel
    @Environment(\.dismiss) private var dismiss
    @State private var query = ""

    private var filteredGroups: [ChannelGroup] {
        let text = query.trimmed
        guard !text.isEmpty else { return model.groups }
        return model.groups.filter {
            $0.name.range(of: text, options: [.caseInsensitive, .diacriticInsensitive]) != nil
        }
    }

    var body: some View {
        NavigationStack {
            List {
                if query.trimmed.isEmpty {
                    Section {
                        row("★ Favoris", count: model.favoritesCount, selection: .favorites)
                        row("Récents", count: model.recentsCount, selection: .recents)
                        row("Toutes les chaînes", count: model.allChannels.count, selection: .all)
                    }
                }
                Section {
                    ForEach(filteredGroups) { group in
                        row(group.name, count: group.count, selection: .group(group.name))
                    }
                } header: {
                    Text("Groupes (\(model.groups.count))")
                }
            }
            .searchable(text: $query, prompt: "Rechercher un groupe")
            .navigationTitle("Groupes")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Fermer") {
                        dismiss()
                    }
                }
            }
        }
    }

    private func row(_ title: String, count: Int, selection: GroupSelection) -> some View {
        Button {
            model.selection = selection
            dismiss()
        } label: {
            HStack {
                Text(title)
                    .foregroundColor(.primary)
                Spacer()
                Text("\(count)")
                    .foregroundColor(.secondary)
                if model.selection == selection {
                    Image(systemName: "checkmark")
                        .foregroundColor(.accentColor)
                }
            }
        }
    }
}

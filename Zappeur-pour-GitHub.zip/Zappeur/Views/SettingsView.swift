import SwiftUI

enum EditorTarget: Identifiable {
    case new
    case edit(PlaylistConfig)

    var id: String {
        switch self {
        case .new: return "new"
        case .edit(let playlist): return playlist.id.uuidString
        }
    }

    var playlist: PlaylistConfig? {
        if case .edit(let playlist) = self {
            return playlist
        }
        return nil
    }
}

/// Réglages : playlists, lecture, guide TV.
@MainActor
struct SettingsView: View {
    @EnvironmentObject private var model: AppModel
    @Environment(\.dismiss) private var dismiss
    @State private var editorTarget: EditorTarget? = nil

    var body: some View {
        NavigationStack {
            Form {
                playlistsSection
                playbackSection
                guideSection
                aboutSection
            }
            .navigationTitle("Réglages")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("OK") {
                        dismiss()
                    }
                }
            }
            .sheet(item: $editorTarget) { target in
                PlaylistEditorView(existing: target.playlist)
                    .environmentObject(model)
            }
        }
    }

    private var playlistsSection: some View {
        Section {
            ForEach(model.playlists) { playlist in
                HStack(spacing: 12) {
                    Button {
                        model.activate(playlist.id)
                    } label: {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(playlist.name)
                                .foregroundColor(.primary)
                            Text(playlist.kind.label)
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                    .buttonStyle(.borderless)
                    Spacer()
                    if playlist.id == model.activePlaylistID {
                        Image(systemName: "checkmark")
                            .foregroundColor(.accentColor)
                    }
                    Button {
                        editorTarget = .edit(playlist)
                    } label: {
                        Image(systemName: "pencil")
                    }
                    .buttonStyle(.borderless)
                    .accessibilityLabel("Modifier")
                }
            }
            .onDelete { offsets in
                model.deletePlaylists(at: offsets)
            }
            Button {
                editorTarget = .new
            } label: {
                Label("Ajouter une playlist", systemImage: "plus")
            }
        } header: {
            Text("Playlists")
        } footer: {
            Text("Touche une playlist pour l'utiliser. Glisse vers la gauche pour la supprimer.")
        }
    }

    private var playbackSection: some View {
        Section {
            Toggle("Privilégier le format HLS", isOn: $model.preferHLS)
        } header: {
            Text("Lecture")
        } footer: {
            Text("Convertit si possible les flux MPEG-TS en HLS, le seul format de direct que le lecteur d'Apple sait lire. À laisser activé.")
        }
    }

    private var guideSection: some View {
        Section {
            HStack {
                Text("État")
                Spacer()
                Text(model.epgStatusDescription)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.trailing)
            }
            Button("Recharger le guide TV") {
                Task { await model.reloadEPG(force: true) }
            }
            Button("Recharger les chaînes") {
                Task { await model.reloadChannels() }
            }
        } header: {
            Text("Guide TV et chaînes")
        } footer: {
            Text("Le guide TV se met à jour tout seul toutes les 12 heures. Il peut être volumineux : privilégie le Wi-Fi.")
        }
    }

    private var aboutSection: some View {
        Section {
            HStack {
                Text("Version")
                Spacer()
                Text(appVersion)
                    .foregroundColor(.secondary)
            }
        } footer: {
            Text("Zappeur est un lecteur : il ne fournit aucune chaîne.")
        }
    }

    private var appVersion: String {
        let info = Bundle.main.infoDictionary
        let version = info?["CFBundleShortVersionString"] as? String ?? "?"
        let build = info?["CFBundleVersion"] as? String ?? "?"
        return "\(version) (\(build))"
    }
}

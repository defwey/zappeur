import SwiftUI

/// Ce qui est ouvert dans le lecteur : la chaîne choisie et la liste dans laquelle on zappe.
struct PlayerSession: Identifiable {
    let id = UUID()
    let channel: Channel
    let context: [Channel]
}

/// Écran principal : liste des chaînes du groupe choisi, recherche, favoris.
@MainActor
struct ChannelListView: View {
    @EnvironmentObject private var model: AppModel
    @State private var query = ""
    @State private var showGroups = false
    @State private var showSettings = false
    @State private var session: PlayerSession? = nil

    private var isSearching: Bool {
        !query.trimmed.isEmpty
    }

    private var visibleChannels: [Channel] {
        isSearching ? model.search(query) : model.channels(for: model.selection)
    }

    private var screenTitle: String {
        isSearching ? "Recherche" : model.title(for: model.selection)
    }

    var body: some View {
        let channels = visibleChannels
        NavigationStack {
            List {
                statusSection
                ForEach(channels) { channel in
                    row(for: channel, context: channels)
                }
                if channels.isEmpty && !model.isLoadingChannels && model.loadError == nil {
                    emptyState
                }
            }
            .listStyle(.plain)
            .safeAreaInset(edge: .top, spacing: 0) {
                if !isSearching {
                    GroupChipsBar()
                }
            }
            .searchable(text: $query, placement: .navigationBarDrawer(displayMode: .automatic), prompt: "Rechercher une chaîne")
            .refreshable {
                await model.reloadChannels()
            }
            .navigationTitle(screenTitle)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                toolbarContent
            }
        }
        .sheet(isPresented: $showGroups) {
            GroupPickerView()
                .environmentObject(model)
        }
        .sheet(isPresented: $showSettings) {
            SettingsView()
                .environmentObject(model)
        }
        .fullScreenCover(item: $session) { session in
            PlayerScreen(session: session, playback: model.playback)
                .environmentObject(model)
        }
    }

    @ToolbarContentBuilder private var toolbarContent: some ToolbarContent {
        ToolbarItem(placement: .navigationBarLeading) {
            Button {
                showGroups = true
            } label: {
                Image(systemName: "line.3.horizontal")
            }
            .accessibilityLabel("Groupes")
        }
        ToolbarItem(placement: .navigationBarTrailing) {
            HStack(spacing: 14) {
                if model.epgStatus == .loading {
                    ProgressView()
                }
                Button {
                    showSettings = true
                } label: {
                    Image(systemName: "gearshape")
                }
                .accessibilityLabel("Réglages")
            }
        }
    }

    private func row(for channel: Channel, context: [Channel]) -> some View {
        let favorite = model.isFavorite(channel)
        let swipeTitle: String = favorite ? "Retirer" : "Favori"
        let menuTitle: String = favorite ? "Retirer des favoris" : "Ajouter aux favoris"
        let icon = favorite ? "star.slash" : "star"
        return Button {
            session = PlayerSession(channel: channel, context: context)
        } label: {
            ChannelRow(channel: channel,
                       isFavorite: favorite,
                       nowNext: model.nowAndNext(for: channel),
                       date: model.now)
        }
        .buttonStyle(.plain)
        .swipeActions(edge: .trailing, allowsFullSwipe: true) {
            Button {
                model.toggleFavorite(channel)
            } label: {
                Label(swipeTitle, systemImage: icon)
            }
            .tint(.yellow)
        }
        .contextMenu {
            Button {
                model.toggleFavorite(channel)
            } label: {
                Label(menuTitle, systemImage: icon)
            }
        }
    }

    @ViewBuilder private var statusSection: some View {
        if model.isLoadingChannels && model.allChannels.isEmpty {
            HStack(spacing: 12) {
                ProgressView()
                Text("Chargement des chaînes…")
                    .foregroundColor(.secondary)
            }
            .padding(.vertical, 8)
        } else if let error = model.loadError {
            VStack(alignment: .leading, spacing: 8) {
                Label(error, systemImage: "exclamationmark.triangle.fill")
                    .foregroundColor(.orange)
                Button("Réessayer") {
                    Task { await model.reloadChannels() }
                }
                .buttonStyle(.bordered)
            }
            .padding(.vertical, 8)
        }
    }

    private var emptyState: some View {
        VStack(spacing: 10) {
            Image(systemName: emptyIcon)
                .font(.largeTitle)
                .foregroundColor(.secondary)
            Text(emptyMessage)
                .multilineTextAlignment(.center)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 40)
        .listRowSeparator(.hidden)
    }

    private var emptyIcon: String {
        if isSearching {
            return "magnifyingglass"
        }
        switch model.selection {
        case .favorites: return "star"
        case .recents: return "clock"
        default: return "tv"
        }
    }

    private var emptyMessage: String {
        if isSearching {
            return "Aucune chaîne ne correspond à ta recherche."
        }
        switch model.selection {
        case .favorites: return "Aucune chaîne favorite pour l'instant.\nGlisse une chaîne vers la gauche pour l'ajouter."
        case .recents: return "Les chaînes que tu regardes apparaîtront ici."
        default: return "Aucune chaîne dans ce groupe."
        }
    }
}

/// Barre de raccourcis horizontale : Favoris, Récents, Toutes, puis les groupes du fournisseur.
@MainActor
struct GroupChipsBar: View {
    @EnvironmentObject private var model: AppModel

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            LazyHStack(spacing: 8) {
                chip("★ Favoris", selection: .favorites)
                chip("Récents", selection: .recents)
                chip("Toutes", selection: .all)
                ForEach(model.groups) { group in
                    chip(group.name, selection: .group(group.name))
                }
            }
            .padding(.horizontal)
            .padding(.vertical, 8)
        }
        .frame(height: 48)
        .background(.bar)
    }

    private func chip(_ title: String, selection: GroupSelection) -> some View {
        let isSelected = model.selection == selection
        return Button {
            model.selection = selection
        } label: {
            Text(title)
                .font(.subheadline.weight(isSelected ? .semibold : .regular))
                .lineLimit(1)
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(Capsule().fill(isSelected ? Color.accentColor : Color.secondary.opacity(0.2)))
                .foregroundColor(isSelected ? .black : .primary)
        }
        .buttonStyle(.plain)
    }
}

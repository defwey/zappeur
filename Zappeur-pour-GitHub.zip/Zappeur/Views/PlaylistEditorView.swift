import SwiftUI

/// Ajout ou modification d'une playlist (Xtream Codes ou lien M3U).
@MainActor
struct PlaylistEditorView: View {
    @EnvironmentObject private var model: AppModel
    @Environment(\.dismiss) private var dismiss

    let existing: PlaylistConfig?

    @State private var kind: PlaylistConfig.Kind = .xtream
    @State private var name = ""
    @State private var server = ""
    @State private var username = ""
    @State private var password = ""
    @State private var m3uURL = ""
    @State private var epgURL = ""
    @State private var isTesting = false
    @State private var testMessage: String? = nil
    @State private var testSucceeded = false
    @State private var didLoad = false

    private var screenTitle: String {
        existing == nil ? "Nouvelle playlist" : "Modifier la playlist"
    }

    private var canSave: Bool {
        switch kind {
        case .xtream:
            return !server.trimmed.isEmpty && !username.trimmed.isEmpty && !password.isEmpty
        case .m3u:
            return URL.lenient(m3uURL) != nil
        }
    }

    private var detectedXtream: (server: String, username: String, password: String)? {
        kind == .m3u ? XtreamAPI.credentials(fromM3U: m3uURL) : nil
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Picker("Type", selection: $kind) {
                        Text("Xtream Codes").tag(PlaylistConfig.Kind.xtream)
                        Text("Lien M3U").tag(PlaylistConfig.Kind.m3u)
                    }
                    .pickerStyle(.segmented)
                    TextField("Nom (ex. : Mon IPTV)", text: $name)
                }
                if kind == .xtream {
                    xtreamSection
                } else {
                    m3uSection
                }
                epgSection
                if kind == .xtream {
                    testSection
                }
            }
            .navigationTitle(screenTitle)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Annuler") {
                        dismiss()
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Enregistrer") {
                        save()
                    }
                    .disabled(!canSave)
                }
            }
            .onAppear {
                loadExisting()
            }
        }
    }

    private var xtreamSection: some View {
        Section {
            TextField("Serveur (ex. : http://exemple.com:8080)", text: $server)
                .keyboardType(.URL)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
            TextField("Nom d'utilisateur", text: $username)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
            SecureField("Mot de passe", text: $password)
        } header: {
            Text("Identifiants Xtream Codes")
        } footer: {
            Text("Le mot de passe est rangé dans le trousseau sécurisé de l'appareil.")
        }
    }

    private var m3uSection: some View {
        Section {
            TextField("http://…/playlist.m3u", text: $m3uURL)
                .keyboardType(.URL)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
        } header: {
            Text("Lien de la playlist M3U")
        } footer: {
            if let credentials = detectedXtream {
                VStack(alignment: .leading, spacing: 6) {
                    Text("Ce lien contient des identifiants Xtream Codes. Le mode Xtream est plus complet (guide TV, meilleure compatibilité).")
                    Button("Passer en mode Xtream Codes") {
                        kind = .xtream
                        server = credentials.server
                        username = credentials.username
                        password = credentials.password
                    }
                }
            }
        }
    }

    private var epgSection: some View {
        Section {
            TextField("Lien XMLTV (facultatif)", text: $epgURL)
                .keyboardType(.URL)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
        } header: {
            Text("Guide TV")
        } footer: {
            Text("Laisse vide pour utiliser le guide fourni par ta playlist.")
        }
    }

    private var testSection: some View {
        Section {
            Button {
                Task { await runTest() }
            } label: {
                HStack {
                    Text("Tester la connexion")
                    Spacer()
                    if isTesting {
                        ProgressView()
                    }
                }
            }
            .disabled(isTesting || !canSave)
            if let message = testMessage {
                Text(message)
                    .font(.footnote)
                    .foregroundColor(testSucceeded ? .green : .orange)
            }
        }
    }

    private func runTest() async {
        isTesting = true
        testMessage = nil
        do {
            let account = try await XtreamAPI.authenticate(server: server,
                                                           username: username.trimmed,
                                                           password: password)
            testSucceeded = true
            testMessage = account.summary
        } catch {
            testSucceeded = false
            testMessage = error.localizedDescription
        }
        isTesting = false
    }

    private func save() {
        var config = existing ?? PlaylistConfig(id: UUID(), name: "", kind: kind, server: "",
                                                username: "", m3uURL: "", epgURL: "")
        config.kind = kind
        let trimmedName = name.trimmed
        if trimmedName.isEmpty {
            config.name = kind == .xtream ? "Xtream Codes" : "Playlist M3U"
        } else {
            config.name = trimmedName
        }
        config.server = server.trimmed
        config.username = username.trimmed
        config.m3uURL = m3uURL.trimmed
        config.epgURL = epgURL.trimmed
        model.save(config, password: kind == .xtream ? password : nil)
        dismiss()
    }

    private func loadExisting() {
        guard !didLoad else { return }
        didLoad = true
        guard let config = existing else { return }
        kind = config.kind
        name = config.name
        server = config.server
        username = config.username
        m3uURL = config.m3uURL
        epgURL = config.epgURL
        password = Keychain.read(account: config.id.uuidString) ?? ""
    }
}

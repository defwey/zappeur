import SwiftUI

@MainActor
struct RootView: View {
    @EnvironmentObject private var model: AppModel

    var body: some View {
        if model.playlists.isEmpty {
            WelcomeView()
        } else {
            ChannelListView()
        }
    }
}

/// Premier lancement : invitation à ajouter une playlist.
@MainActor
struct WelcomeView: View {
    @EnvironmentObject private var model: AppModel
    @State private var showEditor = false

    var body: some View {
        VStack(spacing: 20) {
            Spacer()
            Image(systemName: "play.tv.fill")
                .font(.system(size: 64))
                .foregroundColor(.accentColor)
            Text("Bienvenue dans Zappeur")
                .font(.title.bold())
            Text("Ajoute la playlist de ton fournisseur IPTV pour commencer : identifiants Xtream Codes ou lien M3U.")
                .multilineTextAlignment(.center)
                .foregroundColor(.secondary)
                .padding(.horizontal, 32)
            Button {
                showEditor = true
            } label: {
                Label("Ajouter une playlist", systemImage: "plus")
                    .frame(maxWidth: 260)
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            Spacer()
            Text("Zappeur est un lecteur : il ne fournit aucune chaîne.")
                .font(.footnote)
                .foregroundColor(.secondary)
                .padding(.bottom, 12)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.black.ignoresSafeArea())
        .sheet(isPresented: $showEditor) {
            PlaylistEditorView(existing: nil)
                .environmentObject(model)
        }
    }
}

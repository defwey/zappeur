import Foundation

/// Une chaîne en direct, quelle que soit la source (Xtream Codes ou M3U).
struct Channel: Identifiable, Hashable, Codable {
    let id: String
    let name: String
    let group: String
    let logoURL: URL?
    let streamURL: URL
    /// Identifiant de la chaîne dans le guide TV (tvg-id / epg_channel_id), déjà normalisé.
    let epgID: String?
    let number: Int?
    /// Identifiant du flux côté Xtream Codes (sert au guide TV « court »).
    let xtreamStreamID: Int?

    /// Met les identifiants du guide TV sous une forme comparable (minuscules, sans espaces autour).
    static func normalizeEPGID(_ raw: String?) -> String? {
        guard let raw = raw else { return nil }
        let value = raw.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        return value.isEmpty ? nil : value
    }
}

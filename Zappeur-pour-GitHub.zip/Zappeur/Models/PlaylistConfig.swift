import Foundation

/// Une source de chaînes enregistrée par l'utilisateur.
/// Le mot de passe Xtream n'est jamais stocké ici : il est dans le trousseau (Keychain).
struct PlaylistConfig: Identifiable, Hashable, Codable {
    enum Kind: String, Codable, CaseIterable {
        case xtream
        case m3u

        var label: String {
            switch self {
            case .xtream: return "Xtream Codes"
            case .m3u: return "Lien M3U"
            }
        }
    }

    var id: UUID
    var name: String
    var kind: Kind
    var server: String
    var username: String
    var m3uURL: String
    /// Lien XMLTV facultatif qui remplace le guide fourni par la playlist.
    var epgURL: String
}

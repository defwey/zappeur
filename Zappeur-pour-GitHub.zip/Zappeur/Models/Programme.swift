import Foundation

/// Un programme du guide TV.
struct Programme: Identifiable, Hashable {
    let title: String
    let summary: String
    let start: Date
    let end: Date

    var id: TimeInterval { start.timeIntervalSince1970 }

    func contains(_ date: Date) -> Bool {
        start <= date && date < end
    }

    /// Avancement du programme entre 0 et 1.
    func progress(at date: Date) -> Double {
        let total = end.timeIntervalSince(start)
        guard total > 0 else { return 0 }
        return min(max(date.timeIntervalSince(start) / total, 0), 1)
    }

    /// Trie par heure de début et supprime les doublons (même heure de début).
    static func normalized(_ list: [Programme]) -> [Programme] {
        let sorted = list.sorted { $0.start < $1.start }
        var result: [Programme] = []
        result.reserveCapacity(sorted.count)
        for programme in sorted where result.last?.start != programme.start {
            result.append(programme)
        }
        return result
    }
}
